# Titanium University Polished Glyph Pack

This pack contains the polished Titanium University icon glyphs only — no page mockups.

## Included
- 44 module SVGs
- 6 role-path SVGs
- 4 platform SVGs
- 12 domain/category SVGs
- 1 SVG sprite (`sprite/tu-icons.svg`)
- CSS helper file (`css/tu-icons.css`)
- `manifest.json`

## Design spec
- Canvas: 64 x 64
- Transparent background
- Stroke width: 3.5 px
- Rounded line caps and joins
- Palette: Titanium Lime `#A6FF00`, Cool Steel `#9AA4B2`
- No baked-in glow

## Folder structure
- `svg/modules/`
- `svg/role-paths/`
- `svg/platform/`
- `svg/domains/`

These are symbol-only assets ready for developer handoff.
